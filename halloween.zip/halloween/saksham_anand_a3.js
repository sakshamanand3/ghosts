(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"saksham_anand_a3_atlas_", frames: [[934,1202,521,814],[0,1202,932,576],[0,0,1600,1200]]},
		{name:"saksham_anand_a3_atlas_2", frames: [[1949,263,30,35],[1131,216,396,88],[251,216,330,204],[1116,308,13,13],[1022,338,13,13],[1091,340,13,13],[1106,340,13,13],[845,342,13,13],[1063,342,13,13],[1037,343,13,13],[1022,353,13,13],[1078,355,13,13],[1093,355,13,13],[1108,355,13,13],[845,357,13,13],[1052,357,13,13],[1037,358,13,13],[1022,368,13,13],[1067,370,13,13],[1082,370,13,13],[1097,370,13,13],[1112,370,13,13],[1870,385,13,13],[1885,385,13,13],[1900,385,13,13],[1915,385,13,13],[1930,385,13,13],[1945,385,13,13],[1960,385,13,13],[1975,385,13,13],[1229,386,13,13],[1870,400,13,13],[1885,400,13,13],[1900,400,13,13],[1915,400,13,13],[1930,400,13,13],[1945,400,13,13],[1960,400,13,13],[1975,400,13,13],[1229,401,13,13],[583,404,13,13],[598,404,13,13],[613,404,13,13],[0,0,1601,214],[941,386,286,16],[2019,226,18,232],[583,378,286,24],[1991,226,26,232],[583,342,260,34],[0,216,249,314],[1603,0,344,303],[1479,306,36,134],[583,308,286,32],[1073,328,16,12],[1045,329,16,12],[1529,216,64,57],[1093,308,21,14],[1022,308,29,14],[1529,275,29,22],[1560,275,29,22],[1642,305,116,104],[1093,324,14,14],[1109,324,14,14],[1870,305,119,78],[1131,306,119,78],[1252,306,79,116],[1949,0,87,111],[871,308,68,121],[1408,306,69,121],[1333,306,73,119],[1949,113,87,111],[1073,308,18,18],[1949,226,35,35],[1760,305,108,108],[1529,305,111,141],[1053,308,18,19],[1022,324,21,12],[941,308,79,74],[583,216,546,90]]}
];


// symbols:



(lib.CachedBmp_782 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_781 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_780 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_721 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_722 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_719 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_715 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_713 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_710 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_709 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_704 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_702 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_696 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_718 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_714 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_690 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_689 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_716 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_687 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_684 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_682 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_741 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_711 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_636 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_635 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_631 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_639 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_642 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_624 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_622 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_634 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_616 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_637 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_749 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_633 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_683 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_608 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_703 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_753 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_604 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_609 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_602 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_760 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_600 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_599 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_598 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_597 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_596 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_595 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_594 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_593 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_592 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_591 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_590 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_587 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_584 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_583 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_582 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_581 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_580 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_576 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_579 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_578 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_577 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_514 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_779 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_508 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_507 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_506 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_505 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_504 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_503 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_502 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_501 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_500 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_498 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_496 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_495 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_494 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_493 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_492 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_491 = function() {
	this.initialize(ss["saksham_anand_a3_atlas_2"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_782();
	this.instance.setTransform(549.2,32.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_781();
	this.instance_1.setTransform(339.75,20.15,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_780();
	this.instance_2.setTransform(25.35,495.25,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_779();
	this.instance_3.setTransform(711.85,139.5,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_779();
	this.instance_4.setTransform(711.85,131.75,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_779();
	this.instance_5.setTransform(711.85,124,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_779();
	this.instance_6.setTransform(711.85,116.25,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_779();
	this.instance_7.setTransform(711.85,108.5,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_779();
	this.instance_8.setTransform(711.85,100.75,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_779();
	this.instance_9.setTransform(711.85,93,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_779();
	this.instance_10.setTransform(711.85,85.25,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_779();
	this.instance_11.setTransform(711.85,77.5,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_779();
	this.instance_12.setTransform(711.85,69.75,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_779();
	this.instance_13.setTransform(711.85,62,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_779();
	this.instance_14.setTransform(711.85,54.25,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_779();
	this.instance_15.setTransform(711.85,46.5,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_779();
	this.instance_16.setTransform(711.85,38.75,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_779();
	this.instance_17.setTransform(711.85,31,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_779();
	this.instance_18.setTransform(711.85,23.25,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_779();
	this.instance_19.setTransform(711.85,15.5,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_779();
	this.instance_20.setTransform(711.85,7.75,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_779();
	this.instance_21.setTransform(711.85,0,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_760();
	this.instance_22.setTransform(721,2.3,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_760();
	this.instance_23.setTransform(728.4,2.35,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_760();
	this.instance_24.setTransform(735.75,2.35,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_760();
	this.instance_25.setTransform(742.95,2.35,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_760();
	this.instance_26.setTransform(750.35,2.4,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_760();
	this.instance_27.setTransform(757.7,2.4,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_760();
	this.instance_28.setTransform(765.1,2.4,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_753();
	this.instance_29.setTransform(772.45,2.4,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_760();
	this.instance_30.setTransform(779.85,2.45,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_760();
	this.instance_31.setTransform(787.2,2.45,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_760();
	this.instance_32.setTransform(794.6,2.45,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_749();
	this.instance_33.setTransform(801.95,2.5,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_760();
	this.instance_34.setTransform(809.35,2.5,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_760();
	this.instance_35.setTransform(816.75,2.5,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_760();
	this.instance_36.setTransform(824.1,2.55,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_760();
	this.instance_37.setTransform(831.5,2.55,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_760();
	this.instance_38.setTransform(838.85,2.55,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_760();
	this.instance_39.setTransform(846.25,2.6,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_760();
	this.instance_40.setTransform(853.6,2.6,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_741();
	this.instance_41.setTransform(814.6,104.9,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_741();
	this.instance_42.setTransform(809.4,99.65,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_760();
	this.instance_43.setTransform(804.2,94.45,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_741();
	this.instance_44.setTransform(799.1,89.35,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_741();
	this.instance_45.setTransform(793.9,84.1,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_749();
	this.instance_46.setTransform(788.7,78.9,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_741();
	this.instance_47.setTransform(783.5,73.65,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_760();
	this.instance_48.setTransform(778.3,68.45,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_753();
	this.instance_49.setTransform(773.1,63.2,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_760();
	this.instance_50.setTransform(767.9,58,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_753();
	this.instance_51.setTransform(762.7,52.75,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_749();
	this.instance_52.setTransform(757.45,47.55,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_741();
	this.instance_53.setTransform(752.25,42.3,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_741();
	this.instance_54.setTransform(747.05,37.05,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_749();
	this.instance_55.setTransform(741.85,31.85,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_741();
	this.instance_56.setTransform(736.65,26.6,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_760();
	this.instance_57.setTransform(731.45,21.4,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_753();
	this.instance_58.setTransform(726.25,16.15,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_760();
	this.instance_59.setTransform(721.05,10.95,0.5,0.5);

	this.instance_60 = new lib.CachedBmp_722();
	this.instance_60.setTransform(719.3,120.15,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_721();
	this.instance_61.setTransform(724.8,114.2,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_722();
	this.instance_62.setTransform(730.45,109.15,0.5,0.5);

	this.instance_63 = new lib.CachedBmp_719();
	this.instance_63.setTransform(737.45,104.95,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_718();
	this.instance_64.setTransform(743.85,102.15,0.5,0.5);

	this.instance_65 = new lib.CachedBmp_718();
	this.instance_65.setTransform(750.6,99.35,0.5,0.5);

	this.instance_66 = new lib.CachedBmp_716();
	this.instance_66.setTransform(758.4,96.85,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_715();
	this.instance_67.setTransform(783.25,91.55,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_714();
	this.instance_68.setTransform(791.5,91.9,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_713();
	this.instance_69.setTransform(766.15,94.4,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_718();
	this.instance_70.setTransform(774.7,92.95,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_711();
	this.instance_71.setTransform(800.3,80.75,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_710();
	this.instance_72.setTransform(800.05,72.65,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_709();
	this.instance_73.setTransform(800.55,65.05,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_709();
	this.instance_74.setTransform(802.65,57.15,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_718();
	this.instance_75.setTransform(805.25,50.7,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_718();
	this.instance_76.setTransform(808.1,43.95,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_718();
	this.instance_77.setTransform(811.95,36.75,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_704();
	this.instance_78.setTransform(826,15.55,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_703();
	this.instance_79.setTransform(832.15,10.05,0.5,0.5);

	this.instance_80 = new lib.CachedBmp_702();
	this.instance_80.setTransform(815.8,29.55,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_718();
	this.instance_81.setTransform(820.9,22.55,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_749();
	this.instance_82.setTransform(718.3,81.85,0.5,0.5);

	this.instance_83 = new lib.CachedBmp_760();
	this.instance_83.setTransform(724.8,77.4,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_760();
	this.instance_84.setTransform(732.2,73.9,0.5,0.5);

	this.instance_85 = new lib.CachedBmp_703();
	this.instance_85.setTransform(756.05,65.25,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_696();
	this.instance_86.setTransform(764.35,64.55,0.5,0.5);

	this.instance_87 = new lib.CachedBmp_718();
	this.instance_87.setTransform(739.55,70.4,0.5,0.5);

	this.instance_88 = new lib.CachedBmp_760();
	this.instance_88.setTransform(747.85,67.85,0.5,0.5);

	this.instance_89 = new lib.CachedBmp_753();
	this.instance_89.setTransform(774.3,54.5,0.5,0.5);

	this.instance_90 = new lib.CachedBmp_760();
	this.instance_90.setTransform(775.6,46.8,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_714();
	this.instance_91.setTransform(720.35,41.05,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_690();
	this.instance_92.setTransform(736.6,36.8,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_689();
	this.instance_93.setTransform(728.05,38.4,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_716();
	this.instance_94.setTransform(745.95,24.75,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_687();
	this.instance_95.setTransform(752.4,9.25,0.5,0.5);

	this.instance_96 = new lib.CachedBmp_760();
	this.instance_96.setTransform(748.55,17.05,0.5,0.5);

	this.instance_97 = new lib.CachedBmp_760();
	this.instance_97.setTransform(778.2,39.05,0.5,0.5);

	this.instance_98 = new lib.CachedBmp_684();
	this.instance_98.setTransform(788.55,15.8,0.5,0.5);

	this.instance_99 = new lib.CachedBmp_683();
	this.instance_99.setTransform(793.75,9.4,0.5,0.5);

	this.instance_100 = new lib.CachedBmp_682();
	this.instance_100.setTransform(780.8,31.3,0.5,0.5);

	this.instance_101 = new lib.CachedBmp_753();
	this.instance_101.setTransform(784.7,23.55,0.5,0.5);

	this.instance_102 = new lib.CachedBmp_760();
	this.instance_102.setTransform(703.9,2.3,0.5,0.5);

	this.instance_103 = new lib.CachedBmp_760();
	this.instance_103.setTransform(696.55,2.25,0.5,0.5);

	this.instance_104 = new lib.CachedBmp_760();
	this.instance_104.setTransform(689.15,2.25,0.5,0.5);

	this.instance_105 = new lib.CachedBmp_749();
	this.instance_105.setTransform(681.95,2.25,0.5,0.5);

	this.instance_106 = new lib.CachedBmp_753();
	this.instance_106.setTransform(674.6,2.2,0.5,0.5);

	this.instance_107 = new lib.CachedBmp_760();
	this.instance_107.setTransform(667.2,2.2,0.5,0.5);

	this.instance_108 = new lib.CachedBmp_760();
	this.instance_108.setTransform(659.85,2.2,0.5,0.5);

	this.instance_109 = new lib.CachedBmp_753();
	this.instance_109.setTransform(652.45,2.15,0.5,0.5);

	this.instance_110 = new lib.CachedBmp_760();
	this.instance_110.setTransform(645.1,2.15,0.5,0.5);

	this.instance_111 = new lib.CachedBmp_760();
	this.instance_111.setTransform(637.7,2.15,0.5,0.5);

	this.instance_112 = new lib.CachedBmp_760();
	this.instance_112.setTransform(630.35,2.15,0.5,0.5);

	this.instance_113 = new lib.CachedBmp_760();
	this.instance_113.setTransform(622.95,2.1,0.5,0.5);

	this.instance_114 = new lib.CachedBmp_760();
	this.instance_114.setTransform(615.6,2.1,0.5,0.5);

	this.instance_115 = new lib.CachedBmp_760();
	this.instance_115.setTransform(608.2,2.1,0.5,0.5);

	this.instance_116 = new lib.CachedBmp_749();
	this.instance_116.setTransform(600.8,2.05,0.5,0.5);

	this.instance_117 = new lib.CachedBmp_760();
	this.instance_117.setTransform(593.45,2.05,0.5,0.5);

	this.instance_118 = new lib.CachedBmp_760();
	this.instance_118.setTransform(586.05,2.05,0.5,0.5);

	this.instance_119 = new lib.CachedBmp_753();
	this.instance_119.setTransform(578.7,2,0.5,0.5);

	this.instance_120 = new lib.CachedBmp_760();
	this.instance_120.setTransform(571.3,2,0.5,0.5);

	this.instance_121 = new lib.CachedBmp_753();
	this.instance_121.setTransform(609.9,104.45,0.5,0.5);

	this.instance_122 = new lib.CachedBmp_741();
	this.instance_122.setTransform(615.1,99.25,0.5,0.5);

	this.instance_123 = new lib.CachedBmp_753();
	this.instance_123.setTransform(620.35,94.05,0.5,0.5);

	this.instance_124 = new lib.CachedBmp_760();
	this.instance_124.setTransform(625.45,89,0.5,0.5);

	this.instance_125 = new lib.CachedBmp_749();
	this.instance_125.setTransform(630.65,83.8,0.5,0.5);

	this.instance_126 = new lib.CachedBmp_760();
	this.instance_126.setTransform(635.9,78.6,0.5,0.5);

	this.instance_127 = new lib.CachedBmp_741();
	this.instance_127.setTransform(641.1,73.35,0.5,0.5);

	this.instance_128 = new lib.CachedBmp_753();
	this.instance_128.setTransform(646.35,68.15,0.5,0.5);

	this.instance_129 = new lib.CachedBmp_741();
	this.instance_129.setTransform(651.55,62.95,0.5,0.5);

	this.instance_130 = new lib.CachedBmp_753();
	this.instance_130.setTransform(656.8,57.75,0.5,0.5);

	this.instance_131 = new lib.CachedBmp_741();
	this.instance_131.setTransform(662,52.55,0.5,0.5);

	this.instance_132 = new lib.CachedBmp_760();
	this.instance_132.setTransform(667.25,47.35,0.5,0.5);

	this.instance_133 = new lib.CachedBmp_749();
	this.instance_133.setTransform(672.45,42.15,0.5,0.5);

	this.instance_134 = new lib.CachedBmp_749();
	this.instance_134.setTransform(677.7,36.95,0.5,0.5);

	this.instance_135 = new lib.CachedBmp_760();
	this.instance_135.setTransform(682.95,31.75,0.5,0.5);

	this.instance_136 = new lib.CachedBmp_741();
	this.instance_136.setTransform(688.15,26.5,0.5,0.5);

	this.instance_137 = new lib.CachedBmp_753();
	this.instance_137.setTransform(693.4,21.3,0.5,0.5);

	this.instance_138 = new lib.CachedBmp_741();
	this.instance_138.setTransform(698.6,16.1,0.5,0.5);

	this.instance_139 = new lib.CachedBmp_753();
	this.instance_139.setTransform(703.85,10.9,0.5,0.5);

	this.instance_140 = new lib.CachedBmp_642();
	this.instance_140.setTransform(705.1,120.05,0.5,0.5);

	this.instance_141 = new lib.CachedBmp_642();
	this.instance_141.setTransform(699.6,114.1,0.5,0.5);

	this.instance_142 = new lib.CachedBmp_703();
	this.instance_142.setTransform(693.95,109.05,0.5,0.5);

	this.instance_143 = new lib.CachedBmp_639();
	this.instance_143.setTransform(687,104.85,0.5,0.5);

	this.instance_144 = new lib.CachedBmp_711();
	this.instance_144.setTransform(680.65,102.05,0.5,0.5);

	this.instance_145 = new lib.CachedBmp_637();
	this.instance_145.setTransform(673.9,99.2,0.5,0.5);

	this.instance_146 = new lib.CachedBmp_636();
	this.instance_146.setTransform(666.1,96.7,0.5,0.5);

	this.instance_147 = new lib.CachedBmp_635();
	this.instance_147.setTransform(641.25,91.25,0.5,0.5);

	this.instance_148 = new lib.CachedBmp_634();
	this.instance_148.setTransform(633,91.6,0.5,0.5);

	this.instance_149 = new lib.CachedBmp_633();
	this.instance_149.setTransform(658.35,94.15,0.5,0.5);

	this.instance_150 = new lib.CachedBmp_637();
	this.instance_150.setTransform(649.8,92.7,0.5,0.5);

	this.instance_151 = new lib.CachedBmp_631();
	this.instance_151.setTransform(624.3,80.35,0.5,0.5);

	this.instance_152 = new lib.CachedBmp_639();
	this.instance_152.setTransform(624.55,72.3,0.5,0.5);

	this.instance_153 = new lib.CachedBmp_642();
	this.instance_153.setTransform(624,64.65,0.5,0.5);

	this.instance_154 = new lib.CachedBmp_642();
	this.instance_154.setTransform(621.95,56.75,0.5,0.5);

	this.instance_155 = new lib.CachedBmp_637();
	this.instance_155.setTransform(619.4,50.3,0.5,0.5);

	this.instance_156 = new lib.CachedBmp_637();
	this.instance_156.setTransform(616.6,43.55,0.5,0.5);

	this.instance_157 = new lib.CachedBmp_637();
	this.instance_157.setTransform(612.8,36.35,0.5,0.5);

	this.instance_158 = new lib.CachedBmp_624();
	this.instance_158.setTransform(598.85,15.05,0.5,0.5);

	this.instance_159 = new lib.CachedBmp_634();
	this.instance_159.setTransform(592.7,9.55,0.5,0.5);

	this.instance_160 = new lib.CachedBmp_622();
	this.instance_160.setTransform(609,29.15,0.5,0.5);

	this.instance_161 = new lib.CachedBmp_637();
	this.instance_161.setTransform(603.9,22.1,0.5,0.5);

	this.instance_162 = new lib.CachedBmp_749();
	this.instance_162.setTransform(706.25,81.8,0.5,0.5);

	this.instance_163 = new lib.CachedBmp_760();
	this.instance_163.setTransform(699.8,77.35,0.5,0.5);

	this.instance_164 = new lib.CachedBmp_753();
	this.instance_164.setTransform(692.45,73.8,0.5,0.5);

	this.instance_165 = new lib.CachedBmp_634();
	this.instance_165.setTransform(668.55,65.05,0.5,0.5);

	this.instance_166 = new lib.CachedBmp_616();
	this.instance_166.setTransform(660.35,64.3,0.5,0.5);

	this.instance_167 = new lib.CachedBmp_637();
	this.instance_167.setTransform(685.05,70.25,0.5,0.5);

	this.instance_168 = new lib.CachedBmp_749();
	this.instance_168.setTransform(676.8,67.7,0.5,0.5);

	this.instance_169 = new lib.CachedBmp_753();
	this.instance_169.setTransform(650.4,54.25,0.5,0.5);

	this.instance_170 = new lib.CachedBmp_753();
	this.instance_170.setTransform(649.15,46.5,0.5,0.5);

	this.instance_171 = new lib.CachedBmp_633();
	this.instance_171.setTransform(704.35,41.05,0.5,0.5);

	this.instance_172 = new lib.CachedBmp_683();
	this.instance_172.setTransform(688.2,36.7,0.5,0.5);

	this.instance_173 = new lib.CachedBmp_609();
	this.instance_173.setTransform(696.65,38.35,0.5,0.5);

	this.instance_174 = new lib.CachedBmp_608();
	this.instance_174.setTransform(678.85,24.6,0.5,0.5);

	this.instance_175 = new lib.CachedBmp_703();
	this.instance_175.setTransform(672.4,9.1,0.5,0.5);

	this.instance_176 = new lib.CachedBmp_760();
	this.instance_176.setTransform(676.3,16.9,0.5,0.5);

	this.instance_177 = new lib.CachedBmp_753();
	this.instance_177.setTransform(646.6,38.75,0.5,0.5);

	this.instance_178 = new lib.CachedBmp_604();
	this.instance_178.setTransform(636.25,15.5,0.5,0.5);

	this.instance_179 = new lib.CachedBmp_609();
	this.instance_179.setTransform(631.15,9.05,0.5,0.5);

	this.instance_180 = new lib.CachedBmp_602();
	this.instance_180.setTransform(644,31,0.5,0.5);

	this.instance_181 = new lib.CachedBmp_760();
	this.instance_181.setTransform(640.15,23.25,0.5,0.5);

	this.instance_182 = new lib.CachedBmp_600();
	this.instance_182.setTransform(0,506.5,0.5,0.5);

	this.instance_183 = new lib.CachedBmp_599();
	this.instance_183.setTransform(283.25,427.45,0.5,0.5);

	this.instance_184 = new lib.CachedBmp_598();
	this.instance_184.setTransform(354.2,386.45,0.5,0.5);

	this.instance_185 = new lib.CachedBmp_597();
	this.instance_185.setTransform(4.25,409.45,0.5,0.5);

	this.instance_186 = new lib.CachedBmp_596();
	this.instance_186.setTransform(64.2,356.45,0.5,0.5);

	this.instance_187 = new lib.CachedBmp_595();
	this.instance_187.setTransform(94.5,24,0.5,0.5);

	this.instance_188 = new lib.CachedBmp_594();
	this.instance_188.setTransform(303.7,200.4,0.5,0.5);

	this.instance_189 = new lib.CachedBmp_593();
	this.instance_189.setTransform(306.35,217.15,0.5,0.5);

	this.instance_190 = new lib.CachedBmp_592();
	this.instance_190.setTransform(281.7,65.45,0.5,0.5);

	this.instance_191 = new lib.CachedBmp_591();
	this.instance_191.setTransform(0,311.35,0.5,0.5);

	this.instance_192 = new lib.CachedBmp_590();
	this.instance_192.setTransform(12.2,254.45,0.5,0.5);

	this.instance_193 = new lib.CachedBmp_590();
	this.instance_193.setTransform(101.2,254.45,0.5,0.5);

	this.instance_194 = new lib.CachedBmp_590();
	this.instance_194.setTransform(55.2,254.45,0.5,0.5);

	this.instance_195 = new lib.CachedBmp_587();
	this.instance_195.setTransform(0.25,271.45,0.5,0.5);

	this.instance_196 = new lib.CachedBmp_590();
	this.instance_196.setTransform(433.25,255.45,0.5,0.5);

	this.instance_197 = new lib.CachedBmp_587();
	this.instance_197.setTransform(332.25,272.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_197},{t:this.instance_196},{t:this.instance_195},{t:this.instance_194},{t:this.instance_193},{t:this.instance_192},{t:this.instance_191},{t:this.instance_190},{t:this.instance_189},{t:this.instance_188},{t:this.instance_187},{t:this.instance_186},{t:this.instance_185},{t:this.instance_184},{t:this.instance_183},{t:this.instance_182},{t:this.instance_181},{t:this.instance_180},{t:this.instance_179},{t:this.instance_178},{t:this.instance_177},{t:this.instance_176},{t:this.instance_175},{t:this.instance_174},{t:this.instance_173},{t:this.instance_172},{t:this.instance_171},{t:this.instance_170},{t:this.instance_169},{t:this.instance_168},{t:this.instance_167},{t:this.instance_166},{t:this.instance_165},{t:this.instance_164},{t:this.instance_163},{t:this.instance_162},{t:this.instance_161},{t:this.instance_160},{t:this.instance_159},{t:this.instance_158},{t:this.instance_157},{t:this.instance_156},{t:this.instance_155},{t:this.instance_154},{t:this.instance_153},{t:this.instance_152},{t:this.instance_151},{t:this.instance_150},{t:this.instance_149},{t:this.instance_148},{t:this.instance_147},{t:this.instance_146},{t:this.instance_145},{t:this.instance_144},{t:this.instance_143},{t:this.instance_142},{t:this.instance_141},{t:this.instance_140},{t:this.instance_139},{t:this.instance_138},{t:this.instance_137},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_132},{t:this.instance_131},{t:this.instance_130},{t:this.instance_129},{t:this.instance_128},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113},{t:this.instance_112},{t:this.instance_111},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103},{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_99},{t:this.instance_98},{t:this.instance_97},{t:this.instance_96},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(0,0,860.1,613.5), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_584();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,800,600);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_583();
	this.instance.setTransform(359.4,7.15,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_582();
	this.instance_1.setTransform(346.7,7.15,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_581();
	this.instance_2.setTransform(341,0,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_580();
	this.instance_3.setTransform(25.65,219.35,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_579();
	this.instance_4.setTransform(33.05,202.3,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_578();
	this.instance_5.setTransform(14.1,202.3,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_577();
	this.instance_6.setTransform(0,189.35,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_576();
	this.instance_7.setTransform(204.65,66.35,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_579();
	this.instance_8.setTransform(215.35,45.35,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_578();
	this.instance_9.setTransform(192.4,45.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_577();
	this.instance_10.setTransform(182,32.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,373,241.4), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_779();
	this.instance.setTransform(64.2,240.25,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_779();
	this.instance_1.setTransform(64.2,232.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_779();
	this.instance_2.setTransform(64.2,224.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_779();
	this.instance_3.setTransform(64.2,217,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_779();
	this.instance_4.setTransform(64.2,209.25,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_779();
	this.instance_5.setTransform(64.2,201.5,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_779();
	this.instance_6.setTransform(64.2,193.75,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_779();
	this.instance_7.setTransform(64.2,186,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_779();
	this.instance_8.setTransform(64.2,178.25,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_779();
	this.instance_9.setTransform(64.2,170.5,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_779();
	this.instance_10.setTransform(64.2,162.75,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_779();
	this.instance_11.setTransform(64.2,155,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_779();
	this.instance_12.setTransform(64.2,147.25,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_779();
	this.instance_13.setTransform(64.2,139.5,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_779();
	this.instance_14.setTransform(64.2,131.75,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_779();
	this.instance_15.setTransform(64.2,124,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_779();
	this.instance_16.setTransform(64.2,116.25,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_779();
	this.instance_17.setTransform(64.2,108.5,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_779();
	this.instance_18.setTransform(64.2,100.75,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_779();
	this.instance_19.setTransform(64.2,93,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_779();
	this.instance_20.setTransform(64.2,85.25,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_779();
	this.instance_21.setTransform(64.2,77.5,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_779();
	this.instance_22.setTransform(64.2,69.75,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_779();
	this.instance_23.setTransform(64.2,62,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_779();
	this.instance_24.setTransform(64.2,54.25,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_779();
	this.instance_25.setTransform(64.2,46.5,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_779();
	this.instance_26.setTransform(64.2,38.75,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_779();
	this.instance_27.setTransform(64.2,31,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_779();
	this.instance_28.setTransform(64.2,23.25,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_779();
	this.instance_29.setTransform(64.2,15.5,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_779();
	this.instance_30.setTransform(64.2,7.75,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_779();
	this.instance_31.setTransform(64.2,0,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_779();
	this.instance_32.setTransform(64.2,529.2,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_779();
	this.instance_33.setTransform(64.2,521.45,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_779();
	this.instance_34.setTransform(64.2,513.7,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_779();
	this.instance_35.setTransform(64.2,505.95,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_779();
	this.instance_36.setTransform(64.2,498.2,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_779();
	this.instance_37.setTransform(64.2,490.45,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_779();
	this.instance_38.setTransform(64.2,482.7,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_779();
	this.instance_39.setTransform(64.2,474.95,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_779();
	this.instance_40.setTransform(64.2,467.2,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_779();
	this.instance_41.setTransform(64.2,459.45,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_779();
	this.instance_42.setTransform(64.2,451.7,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_779();
	this.instance_43.setTransform(64.2,443.95,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_779();
	this.instance_44.setTransform(64.2,436.2,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_779();
	this.instance_45.setTransform(64.2,428.45,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_779();
	this.instance_46.setTransform(64.2,420.7,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_779();
	this.instance_47.setTransform(64.2,412.95,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_779();
	this.instance_48.setTransform(64.2,405.2,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_779();
	this.instance_49.setTransform(64.2,397.45,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_779();
	this.instance_50.setTransform(64.2,389.7,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_779();
	this.instance_51.setTransform(64.2,381.95,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_779();
	this.instance_52.setTransform(64.2,374.2,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_779();
	this.instance_53.setTransform(64.2,366.45,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_779();
	this.instance_54.setTransform(64.2,358.7,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_779();
	this.instance_55.setTransform(64.2,350.95,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_779();
	this.instance_56.setTransform(64.2,343.2,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_779();
	this.instance_57.setTransform(64.2,335.45,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_514();
	this.instance_58.setTransform(64.2,327.75,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_779();
	this.instance_59.setTransform(64.2,320,0.5,0.5);

	this.instance_60 = new lib.CachedBmp_779();
	this.instance_60.setTransform(64.2,312.25,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_779();
	this.instance_61.setTransform(64.2,304.5,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_779();
	this.instance_62.setTransform(64.2,296.75,0.5,0.5);

	this.instance_63 = new lib.CachedBmp_779();
	this.instance_63.setTransform(64.2,289,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_508();
	this.instance_64.setTransform(77.45,539.25,0.5,0.5);

	this.instance_65 = new lib.CachedBmp_507();
	this.instance_65.setTransform(0,539.25,0.5,0.5);

	this.instance_66 = new lib.CachedBmp_506();
	this.instance_66.setTransform(15.25,550.85,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_505();
	this.instance_67.setTransform(83.55,480.6,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_504();
	this.instance_68.setTransform(74.35,474.2,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_503();
	this.instance_69.setTransform(27.85,474.2,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_502();
	this.instance_70.setTransform(81.8,549.6,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_501();
	this.instance_71.setTransform(8.75,480.6,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_500();
	this.instance_72.setTransform(74,569.1,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_500();
	this.instance_73.setTransform(50.3,569.1,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_498();
	this.instance_74.setTransform(69.45,561.8,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_498();
	this.instance_75.setTransform(46.65,561.8,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_496();
	this.instance_76.setTransform(41.2,521.7,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_495();
	this.instance_77.setTransform(40.25,474.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,137,609.1), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1();
	this.instance.setTransform(68.4,304.6,1,1,0,0,0,68.4,304.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,137,609.1), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Spider = new lib.Symbol3();
	this.Spider.name = "Spider";
	this.Spider.setTransform(68.4,304.6,1,1,0,0,0,68.4,304.6);

	this.timeline.addTween(cjs.Tween.get(this.Spider).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,137,609.1), null);


// stage content:
(lib.saksham_anand_a3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		
		
		
		
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		window.addEventListener('click', function(){
		/*
		Play a Movie Clip/Video or the current timeline.
		Plays the specified movie clip or video.
		*/
		_this.play();
		});
		var _this = this;
		
		
		window.addEventListener('keydown', function(){
			if(event.keyCode === 13) {
				_this.faces.y -= 10;
				}		
				
			});
		playSound("Magical_Dirt");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50));

	// text
	this.instance = new lib.CachedBmp_491();
	this.instance.setTransform(134.5,684);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:134.3889,y:640.3333},0).wait(1).to({x:134.2778,y:596.6667},0).wait(1).to({x:134.1667,y:553},0).wait(1).to({x:134.0556,y:509.3333},0).wait(1).to({x:133.9444,y:465.6667},0).wait(1).to({x:133.8333,y:422},0).wait(1).to({x:133.7222,y:378.3333},0).wait(1).to({x:133.6111,y:334.6667},0).wait(1).to({x:133.5,y:291},0).wait(41));

	// spider
	this.spidermove = new lib.Symbol5();
	this.spidermove.name = "spidermove";
	this.spidermove.setTransform(716.2,-363.6,1,1,0,0,0,68.4,304.6);

	this.timeline.addTween(cjs.Tween.get(this.spidermove).wait(1).to({regX:68.5,x:716.3,y:-286.9},0).wait(1).to({y:-210.25},0).wait(1).to({y:-133.6},0).wait(1).to({y:-56.9},0).wait(1).to({y:19.75},0).wait(1).to({y:96.4},0).wait(44));

	// House
	this.house = new lib.Symbol6();
	this.house.name = "house";
	this.house.setTransform(429.75,295.3,1,1,0,0,0,430,306.7);

	this.timeline.addTween(cjs.Tween.get(this.house).wait(50));

	// Faces
	this.faces = new lib.Symbol2();
	this.faces.name = "faces";
	this.faces.setTransform(200.5,393.4,1,1,0,0,0,186.5,120.7);

	this.timeline.addTween(cjs.Tween.get(this.faces).wait(50));

	// Diagonal_Face
	this.instance_1 = new lib.CachedBmp_494();
	this.instance_1.setTransform(382.6,466.6,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_493();
	this.instance_2.setTransform(366.85,477.15,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_492();
	this.instance_3.setTransform(362.3,461.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(50));

	// Layer_1
	this.bg = new lib.Symbol4();
	this.bg.name = "bg";
	this.bg.setTransform(400,300,1,1,0,0,0,400,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(399.8,-368.2,460.09999999999997,1142.2);
// library properties:
lib.properties = {
	id: '6AD90D670CF5451B88AD88F7989396C2',
	width: 800,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/saksham_anand_a3_atlas_.png?1585671006050", id:"saksham_anand_a3_atlas_"},
		{src:"images/saksham_anand_a3_atlas_2.png?1585671006052", id:"saksham_anand_a3_atlas_2"},
		{src:"sounds/Magical_Dirt.mp3?1585671006150", id:"Magical_Dirt"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6AD90D670CF5451B88AD88F7989396C2'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;